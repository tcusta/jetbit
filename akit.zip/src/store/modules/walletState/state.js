const state = () => ({
  web3: null,
  userAccount: null,
});
export default state;
